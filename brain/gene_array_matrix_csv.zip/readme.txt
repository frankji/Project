==============================================
BrainSpan: Atlas of the Developing Human Brain
==============================================

This data set contains expression levels for exons measured by microarray profiling (see the whitepaper at
www.brainspan.org) averaged to genes.

expression_matrix.csv -- the rows are genes and the columns samples; the first column is the row number
rows_metadata.csv -- the genes are listed in the same order as the rows in expression_matrix.csv
columns_metadata.csv -- the samples are listed in the same order as the columns in expression_matrix.csv
